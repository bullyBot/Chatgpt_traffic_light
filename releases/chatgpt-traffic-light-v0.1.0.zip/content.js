(() => {
  // src/detector.js
  var UNTRUSTED = '[data-message-author-role], pre, code, blockquote, [contenteditable="true"], textarea';
  var STATUS_SELECTORS = '[data-task-status], [data-testid="task-status"], [data-testid="task-status-badge"]';
  var PENDING_SELECTORS = '[data-testid="approval-request"], [data-testid="request-user-input"], [data-testid="permission-request"]';
  var STOP_SELECTORS = '[data-testid="stop-button"], button[aria-label="Stop generating"], button[aria-label="\u505C\u6B62\u751F\u6210"]';
  var normalize = (value) => (value || "").replace(/\s+/g, " ").trim().toLowerCase();
  var pending = /^(awaiting[_ -](approval|input|review)|waiting for (approval|input|review)|needs review|requires action|等待批准|等待审批|等待输入|等待审阅|需要审阅|需要你处理)$/;
  var running = /^(running|in progress|working|queued|执行中|进行中|运行中|排队中)$/;
  var completed = /^(completed|complete|done|已完成|任务完成)$/;
  var failed = /^(failed|error|cancelled|canceled|失败|出错|已取消)$/;
  var approve = /^(approve|allow once|allow for this session|approve once|批准|允许一次|本次允许|允许本次会话|批准一次)$/;
  function visible(element) {
    if (!element || element.closest('[hidden], [aria-hidden="true"], [inert]')) return false;
    const win = element.ownerDocument.defaultView;
    for (let node = element; node?.nodeType === 1; node = node.parentElement) {
      const style = win.getComputedStyle(node);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return false;
    }
    return /jsdom/i.test(win.navigator.userAgent) || element.getClientRects().length > 0;
  }
  function safe(element) {
    return visible(element) && !element.closest(UNTRUSTED);
  }
  function hash(text) {
    let value = 2166136261;
    for (let i = 0; i < text.length; i++) value = Math.imul(value ^ text.charCodeAt(i), 16777619);
    return (value >>> 0).toString(36);
  }
  function replyEvidence(doc) {
    const messages = [...doc.querySelectorAll('[data-message-author-role="assistant"]')].filter(visible);
    const last = messages.at(-1);
    if (!last) return { key: "", finished: false };
    const turn = last.closest('article, [data-testid^="conversation-turn-"]') || last;
    const key = hash((last.getAttribute("data-message-id") || turn.id || "") + ":" + last.textContent);
    const good = [...turn.querySelectorAll('[data-testid="good-response-turn-action-button"]')].some(safe);
    const bad = [...turn.querySelectorAll('[data-testid="bad-response-turn-action-button"]')].some(safe);
    return { key, finished: Boolean(last.textContent.trim() && good && bad) };
  }
  function isStopControl(target) {
    const element = target?.closest?.(STOP_SELECTORS);
    return element && safe(element);
  }
  function detect(doc, href) {
    const url = new URL(href);
    const main = doc.querySelector('main, [role="main"]');
    const isChat = /^\/(c\/[\w-]+|g\/[^/]+(?:\/c\/[\w-]+)?|)$/.test(url.pathname);
    const isTask = /^\/(codex|work)\/(tasks?|task)\/[^/]+\/?$/.test(url.pathname);
    const kind = isTask ? "task" : "chat";
    const base = { kind, state: "unknown", reason: "\u5C1A\u672A\u8BC6\u522B\u5230\u53D7\u652F\u6301\u7684\u4EFB\u52A1\u72B6\u6001", completionKey: "" };
    if (!main || !isChat && !isTask) return base;
    const reply = isChat ? replyEvidence(doc) : { key: "", finished: false };
    base.completionKey = reply.key;
    const markers = [...main.querySelectorAll(STATUS_SELECTORS)].filter(safe);
    const markerValues = markers.map((el) => normalize(el.getAttribute("data-task-status") || el.textContent));
    const requests = [...main.querySelectorAll(PENDING_SELECTORS)].filter(safe);
    const dialogs = [...doc.querySelectorAll('[role="dialog"], [role="alertdialog"]')].filter(safe);
    const approval = dialogs.find((dialog) => [...dialog.querySelectorAll("button")].some((button) => safe(button) && !button.disabled && button.getAttribute("aria-disabled") !== "true" && approve.test(normalize(button.textContent || button.getAttribute("aria-label")))));
    const request = requests.find((el) => [...el.querySelectorAll("button, input, textarea, select")].some((control) => visible(control) && !control.disabled));
    if (markerValues.some((value) => pending.test(value)) || approval || request) {
      const source = approval || request;
      const label = source?.querySelector('h1, h2, h3, [role="heading"]')?.textContent || markerValues.find((value) => pending.test(value)) || "\u5F85\u5904\u7406\u8BF7\u6C42";
      return { ...base, state: "attention", reason: "\u9875\u9762\u6B63\u5728\u7B49\u5F85\u6279\u51C6\u3001\u5BA1\u9605\u6216\u56DE\u7B54", attentionKey: hash(label + ":" + (source?.getAttribute("data-testid") || "status")) };
    }
    if ([...main.querySelectorAll(STOP_SELECTORS)].some(safe) || markerValues.some((value) => running.test(value))) {
      return { ...base, state: "running", reason: "\u9875\u9762\u663E\u793A\u4EFB\u52A1\u6B63\u5728\u6267\u884C" };
    }
    if (markerValues.some((value) => failed.test(value))) return { ...base, state: "error", reason: "\u9875\u9762\u663E\u793A\u4EFB\u52A1\u5931\u8D25\u6216\u53D6\u6D88\uFF0C\u8BF7\u67E5\u770B\u4EFB\u52A1" };
    if (isTask && markerValues.some((value) => completed.test(value))) {
      return { ...base, state: "completed", completionKey: "task:" + url.pathname, reason: "\u4EFB\u52A1\u72B6\u6001\u663E\u793A\u5DF2\u5B8C\u6210" };
    }
    if (isChat && reply.finished) return { ...base, state: "completed", reason: "\u672C\u6761\u56DE\u590D\u51FA\u73B0\u53CD\u9988\u63A7\u4EF6" };
    if (isChat && [...main.querySelectorAll('#prompt-textarea, textarea[data-testid="prompt-textarea"]')].some(visible)) {
      return { ...base, state: "idle", reason: "\u804A\u5929\u8F93\u5165\u6846\u5DF2\u5C31\u7EEA" };
    }
    return base;
  }

  // src/model.js
  function canonicalUrl(value) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || !["chatgpt.com", "chat.openai.com"].includes(url.hostname)) return null;
      return url.origin + url.pathname;
    } catch {
      return null;
    }
  }

  // src/content.js
  var currentUrl = canonicalUrl(location.href);
  var documentId = crypto.randomUUID();
  var lastSignature = "";
  var lastSent = 0;
  var pendingTimer;
  var stopped = false;
  function report(cancelled = false, force = false) {
    if (stopped) return;
    const url = canonicalUrl(location.href);
    if (!url) return;
    if (url !== currentUrl) {
      currentUrl = url;
      documentId = crypto.randomUUID();
      lastSignature = "";
    }
    const observation = { ...detect(document, location.href), url, documentId, cancelled, title: document.title.slice(0, 120) };
    const signature = JSON.stringify(observation);
    if (!force && signature === lastSignature && observation.state !== "completed" && Date.now() - lastSent < 15e3) return;
    lastSignature = signature;
    lastSent = Date.now();
    try {
      chrome.runtime.sendMessage({ type: "observation", observation }).catch(() => {
        if (!chrome.runtime?.id) stop();
      });
    } catch {
      stop();
    }
  }
  var observer = new MutationObserver(() => {
    if (pendingTimer) return;
    pendingTimer = setTimeout(() => {
      pendingTimer = null;
      report();
    }, 120);
  });
  observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
  var interval = setInterval(() => report(), 2e3);
  function stop() {
    stopped = true;
    observer.disconnect();
    clearInterval(interval);
    clearTimeout(pendingTimer);
  }
  document.addEventListener("click", (event) => {
    if (isStopControl(event.target)) report(true, true);
  }, true);
  document.addEventListener("pointerdown", (event) => {
    if (isStopControl(event.target)) report(true, true);
  }, true);
  document.addEventListener("keydown", (event) => {
    if (isStopControl(event.target) && ["Enter", " "].includes(event.key)) report(true, true);
    if (event.key === "Escape" && [...document.querySelectorAll('main button, [role="main"] button')].some(isStopControl)) report(true, true);
  }, true);
  document.addEventListener("visibilitychange", () => report(false, true));
  window.addEventListener("pageshow", () => report(false, true));
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "scan") report(false, true);
  });
  report(false, true);
})();
