// src/model.js
var CONFIRM_MS = 2500;
var STALE_MS = 9e4;
var LABELS = {
  running: "\u6B63\u5728\u8FDB\u884C",
  attention: "\u9700\u8981\u4F60\u5904\u7406",
  complete: "\u5DF2\u5B8C\u6210",
  idle: "\u7A7A\u95F2",
  stopped: "\u5DF2\u505C\u6B62",
  unknown: "\u672A\u8BC6\u522B",
  error: "\u4EFB\u52A1\u5F02\u5E38"
};
function canonicalUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || !["chatgpt.com", "chat.openai.com"].includes(url.hostname)) return null;
    return url.origin + url.pathname;
  } catch {
    return null;
  }
}
function transition(previous, observation, now) {
  const sameDocument = previous?.documentId === observation.documentId && previous?.url === observation.url;
  const old = sameDocument ? previous : null;
  const task = {
    ...old,
    url: observation.url,
    documentId: observation.documentId,
    title: observation.title || "ChatGPT \u4EFB\u52A1",
    lastSeen: now,
    diagnostics: observation.diagnostics || null,
    cycle: old?.cycle || 0,
    active: old?.active || false,
    status: "unknown",
    reason: observation.reason || "",
    candidate: null,
    waitingForUser: false
  };
  const events = [];
  const startCycle = () => {
    task.cycle += 1;
    task.active = true;
    task.baseline = observation.completionKey || "";
    task.cancelled = false;
    task.notifiedAttention = null;
  };
  if (observation.cancelled) {
    task.status = "stopped";
    task.active = false;
    task.cancelled = true;
    task.reason = "\u5DF2\u505C\u6B62\uFF1B\u4E0D\u4F1A\u53D1\u9001\u5B8C\u6210\u63D0\u9192";
    return { task, events };
  }
  const answered = observation.diagnostics?.reply?.latestRole === "user";
  const terminalTask = observation.state === "completed" && observation.completionKey?.startsWith("task:") && observation.completionKey !== old?.baseline;
  if ((old?.waitingForUser || old?.status === "attention") && !answered && !terminalTask && ["unknown", "idle", "completed"].includes(observation.state)) {
    task.status = "attention";
    task.waitingForUser = true;
    task.reason = "\u6B63\u5728\u7B49\u5F85\u4F60\u5904\u7406\uFF1B\u56DE\u590D\u7ED3\u675F\u6216\u8F93\u5165\u6846\u5C31\u7EEA\u4E0D\u4EE3\u8868\u8BF7\u6C42\u5DF2\u89E3\u51B3";
    return { task, events };
  }
  if (observation.state === "running") {
    if (old?.cancelled) {
      task.status = "stopped";
      task.reason = "\u6B63\u5728\u505C\u6B62\uFF1B\u4E0D\u4F1A\u53D1\u9001\u5B8C\u6210\u63D0\u9192";
      return { task, events };
    }
    if (!task.active) startCycle();
    task.status = "running";
    task.notifiedAttention = null;
  } else if (observation.state === "attention") {
    if (!task.active) startCycle();
    task.cancelled = false;
    task.status = "attention";
    task.waitingForUser = true;
    const key = observation.attentionKey || observation.reason;
    if (task.notifiedAttention !== key) events.push("attention");
    task.attentionKey = key;
    task.notifiedAttention = key;
  } else if (observation.state === "completed") {
    task.cancelled = false;
    const key = observation.completionKey;
    if (old?.status === "complete" && old?.finishedKey === key) {
      task.status = "complete";
    } else if (task.active && key && key !== task.baseline) {
      const candidate = old?.candidate?.key === key && now - old.lastSeen <= STALE_MS ? old.candidate : { key, since: now };
      task.candidate = candidate;
      task.status = "unknown";
      task.reason = "\u68C0\u6D4B\u5230\u7ED3\u675F\u6807\u8BB0\uFF0C\u6B63\u5728\u786E\u8BA4";
      if (now - candidate.since >= CONFIRM_MS) {
        task.status = "complete";
        task.active = false;
        task.finishedKey = key;
        task.candidate = null;
        task.reason = "\u5DF2\u786E\u8BA4\u672C\u8F6E\u4EFB\u52A1\u5B8C\u6210";
        events.push("complete");
      }
    } else {
      task.status = task.active ? "unknown" : "idle";
      task.reason = task.active ? "\u7B49\u5F85\u672C\u8F6E\u4EFB\u52A1\u7684\u5B8C\u6210\u8BC1\u636E" : "\u5DF2\u6709\u7ED3\u675F\u6807\u8BB0\uFF1B\u672A\u89C2\u5BDF\u5230\u672C\u8F6E\u6267\u884C\uFF0C\u4E0D\u53D1\u9001\u901A\u77E5";
    }
  } else if (observation.state === "idle") {
    task.cancelled = false;
    task.status = task.active ? "unknown" : "idle";
    if (task.active) task.reason = "\u6267\u884C\u4FE1\u53F7\u5DF2\u6D88\u5931\uFF0C\u5C1A\u672A\u786E\u8BA4\u5B8C\u6210";
  } else if (observation.state === "error") {
    task.status = "error";
    task.active = false;
    task.cancelled = false;
  } else if (observation.state === "stopped") {
    task.status = "stopped";
    task.active = false;
    task.cancelled = false;
  } else if (old?.status === "stopped" && !task.active) {
    task.status = "stopped";
    task.cancelled = false;
    task.reason = old.reason;
  }
  return { task, events };
}
function displayedTask(task, now) {
  if (now - task.lastSeen > STALE_MS) return { ...task, status: "unknown", reason: "\u9875\u9762\u6682\u672A\u66F4\u65B0\uFF0C\u8BF7\u6253\u5F00\u4EFB\u52A1\u786E\u8BA4" };
  return task;
}
function aggregate(tasks) {
  for (const status of ["attention", "running", "error", "unknown", "stopped", "complete", "idle"]) {
    if (tasks.some((task) => task.status === status)) return status;
  }
  return "unknown";
}

// src/connection.js
var SITES = ["https://chatgpt.com/*", "https://chat.openai.com/*"];
async function connectTab(api, tab) {
  if (tab.discarded) return { ok: false, reason: "\u9875\u9762\u5DF2\u4F11\u7720\uFF0C\u8BF7\u6253\u5F00\u6B64\u6807\u7B7E\u9875\u540E\u91CD\u8BD5" };
  try {
    const response = await api.tabs.sendMessage(tab.id, { type: "scan" });
    if (response?.ok) return { ok: true, injected: false };
  } catch {
  }
  try {
    await api.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    const response = await api.tabs.sendMessage(tab.id, { type: "scan" });
    if (response?.ok) return { ok: true, injected: true };
    return { ok: false, reason: "\u9875\u9762\u811A\u672C\u672A\u8FD4\u56DE\u72B6\u6001\uFF0C\u8BF7\u5237\u65B0\u8BE5\u9875\u9762\u540E\u91CD\u65B0\u8FDE\u63A5" };
  } catch (error) {
    const permission = /permission|cannot access|not allowed|missing host|extensions gallery/i.test(error.message || "");
    return { ok: false, reason: permission ? "\u6CA1\u6709\u6B64\u9875\u9762\u7684\u8BBF\u95EE\u6743\u9650\uFF0C\u8BF7\u5728\u6269\u5C55\u7684\u201C\u7F51\u7AD9\u8BBF\u95EE\u6743\u9650\u201D\u4E2D\u5141\u8BB8 ChatGPT" : "\u9875\u9762\u6682\u65F6\u65E0\u6CD5\u8FDE\u63A5\uFF0C\u8BF7\u5237\u65B0\u8BE5\u9875\u9762\u540E\u91CD\u8BD5" };
  }
}

// src/lamp.js
var COLORS = { running: "#54d69a", attention: "#f5bd4f", complete: "#ef6461", idle: "#ef6461", stopped: "#ef6461", error: "#ef6461" };
function lampPixels(status, size) {
  const color = COLORS[status] || "#263241";
  const base = color.match(/\w\w/g).map((value) => parseInt(value, 16));
  const pixels = new Uint8ClampedArray(size * size * 4);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const nx = (x + 0.5 - size / 2) / (size / 2);
    const ny = (y + 0.5 - size / 2) / (size / 2);
    const radius = Math.hypot(nx, ny);
    const offset = (y * size + x) * 4;
    if (radius > 0.98) continue;
    let rgb;
    if (radius > 0.82) {
      const light = Math.max(0, (-nx - ny) / 2);
      const rim = radius > 0.93 ? 28 : 48 + 70 * light;
      rgb = [rim, rim + 8, rim + 15];
    } else {
      const shade = 1 - 0.38 * Math.pow(radius / 0.82, 3);
      const reflection = 0.38 * Math.exp(-((nx + 0.28) ** 2 / 0.15 + (ny + 0.4) ** 2 / 0.025));
      const texture = size >= 32 ? 0.015 * Math.cos(x * 2.4) * Math.cos(y * 2.4) : 0;
      rgb = base.map((channel) => channel * (shade + texture) + (255 - channel) * reflection);
    }
    pixels.set([...rgb, Math.min(1, (0.98 - radius) * size) * 255], offset);
  }
  return pixels;
}

// src/usage.js
async function readUsageInPage() {
  if (location.origin !== "https://chatgpt.com") return { ok: false, reason: "\u8BF7\u6253\u5F00\u5E76\u767B\u5F55 chatgpt.com \u540E\u91CD\u8BD5" };
  async function get(path, headers = {}) {
    return fetch(path, { headers, credentials: "include", cache: "no-store", redirect: "error", signal: AbortSignal.timeout(1e4) });
  }
  function failure(status) {
    return { ok: false, reason: status === 401 ? "\u767B\u5F55\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55 ChatGPT" : status === 403 ? "\u5F53\u524D\u8D26\u53F7\u6216\u9875\u9762\u65E0\u6CD5\u8BFB\u53D6\u7528\u91CF\uFF0C\u8BF7\u67E5\u770B\u5B98\u65B9\u7528\u91CF\u9875" : status === 429 ? "\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u5237\u65B0\u989D\u5EA6" : `\u5B98\u65B9\u7528\u91CF\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\uFF08HTTP ${status}\uFF09` };
  }
  try {
    const sessionResponse = await get("/api/auth/session");
    if (!sessionResponse.ok) return failure(sessionResponse.status);
    const session = await sessionResponse.json();
    if (typeof session.accessToken !== "string" || !session.accessToken) return { ok: false, reason: "\u8BF7\u5148\u767B\u5F55 ChatGPT\uFF0C\u518D\u5237\u65B0\u989D\u5EA6" };
    const response = await get("/backend-api/wham/usage", { Authorization: `Bearer ${session.accessToken}` });
    if (!response.ok) return failure(response.status);
    const payload = await response.json();
    const limits = [payload.rate_limit?.primary_window, payload.rate_limit?.secondary_window];
    const window = limits.find((value) => value?.limit_window_seconds === 18e3);
    if (!window) return { ok: false, reason: "\u5B98\u65B9\u672A\u8FD4\u56DE\u6B64\u8D26\u53F7\u7684 5 \u5C0F\u65F6\u989D\u5EA6\uFF0C\u8BF7\u67E5\u770B\u5B98\u65B9\u7528\u91CF\u9875" };
    const used = window.used_percent;
    const resetAt = window.reset_at * 1e3;
    if (typeof used !== "number" || !Number.isFinite(used) || used < 0 || used > 100 || typeof window.reset_at !== "number" || !Number.isFinite(resetAt) || resetAt <= 0 || resetAt > 864e13) {
      return { ok: false, reason: "\u5B98\u65B9\u7528\u91CF\u6570\u636E\u683C\u5F0F\u5DF2\u53D8\u5316\uFF0C\u8BF7\u67E5\u770B\u5B98\u65B9\u7528\u91CF\u9875" };
    }
    return { ok: true, remainingPercent: 100 - used, resetAt, fetchedAt: Date.now() };
  } catch {
    return { ok: false, reason: "\u5B98\u65B9\u7528\u91CF\u8BFB\u53D6\u5931\u8D25\u6216\u8D85\u65F6\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" };
  }
}
async function loadUsage(api) {
  try {
    const tabs = await api.tabs.query({ url: "https://chatgpt.com/*" });
    const supported = tabs.filter((tab2) => {
      try {
        return new URL(tab2.url).origin === "https://chatgpt.com" && !tab2.discarded;
      } catch {
        return false;
      }
    });
    const active = await api.tabs.query({ active: true, currentWindow: true, url: "https://chatgpt.com/*" });
    const tab = supported.find((tab2) => active.some((item) => item.id === tab2.id)) || supported[0];
    if (!tab) return { ok: false, reason: "\u8BF7\u6253\u5F00\u5E76\u767B\u5F55 ChatGPT \u9875\u9762\uFF0C\u518D\u5237\u65B0\u989D\u5EA6" };
    const results = await api.scripting.executeScript({ target: { tabId: tab.id }, world: "ISOLATED", func: readUsageInPage });
    return results?.[0]?.result || { ok: false, reason: "\u9875\u9762\u672A\u8FD4\u56DE\u5B98\u65B9\u7528\u91CF\uFF0C\u8BF7\u91CD\u8BD5" };
  } catch {
    return { ok: false, reason: "\u65E0\u6CD5\u8FDE\u63A5 ChatGPT \u9875\u9762\uFF0C\u8BF7\u68C0\u67E5\u6269\u5C55\u7684\u7F51\u7AD9\u8BBF\u95EE\u6743\u9650" };
  }
}

// src/background.js
var usageRequest;
var queue = Promise.resolve();
function serial(work) {
  const next = queue.then(work);
  queue = next.catch((error) => console.error("Traffic light:", error.message));
  return next;
}
async function read() {
  const { records = {}, notices = {}, notificationError = "" } = await chrome.storage.session.get(["records", "notices", "notificationError"]);
  return { records, notices, notificationError };
}
function icon(status, size) {
  return new ImageData(lampPixels(status, size), size, size);
}
async function render(records) {
  const tasks = Object.values(records).map((task) => displayedTask(task, Date.now()));
  const status = aggregate(tasks);
  const attentionCount = new Set(tasks.filter((task) => task.status === "attention").map((task) => task.url)).size;
  await Promise.all([
    chrome.action.setIcon({ imageData: { 16: icon(status, 16), 32: icon(status, 32) } }),
    chrome.action.setBadgeText({ text: attentionCount ? String(attentionCount) : "" }),
    chrome.action.setBadgeBackgroundColor({ color: COLORS.attention }),
    chrome.action.setTitle({ title: `ChatGPT \u4EFB\u52A1\u7EA2\u7EFF\u706F \xB7 ${tasks.length ? LABELS[status] : "\u7B49\u5F85\u6253\u5F00\u4EFB\u52A1\u9875\u9762"}` })
  ]);
}
function validObservation(value, sender) {
  const sourceUrl = canonicalUrl(sender.url);
  return sender.tab?.id !== void 0 && sender.frameId === 0 && value && typeof value.url === "string" && canonicalUrl(value.url) === value.url && sourceUrl && new URL(sourceUrl).origin === new URL(value.url).origin && typeof value.documentId === "string" && value.documentId.length <= 100 && ["running", "attention", "completed", "idle", "stopped", "unknown", "error"].includes(value.state) && ["chat", "task"].includes(value.kind) && ["title", "reason", "completionKey", "attentionKey"].every((key) => value[key] === void 0 || typeof value[key] === "string" && value[key].length <= 500);
}
var connectionRun;
async function reconnect() {
  if (connectionRun) return connectionRun;
  connectionRun = (async () => {
    let tabs;
    try {
      tabs = await chrome.tabs.query({ url: SITES });
    } catch {
      await chrome.storage.session.set({ connectionError: "\u65E0\u6CD5\u67E5\u627E ChatGPT \u9875\u9762\uFF0C\u8BF7\u68C0\u67E5\u6269\u5C55\u7684\u7F51\u7AD9\u8BBF\u95EE\u6743\u9650" });
      return { ok: false };
    }
    const results = await Promise.all(tabs.map(async (tab) => {
      const result = await connectTab(chrome, tab);
      if (!result.ok && canonicalUrl(tab.url)) await serial(async () => {
        const data = await read();
        data.records[tab.id] = {
          ...data.records[tab.id],
          tabId: tab.id,
          url: canonicalUrl(tab.url),
          documentId: `unconnected:${tab.id}`,
          active: false,
          candidate: null,
          title: tab.title || "ChatGPT \u9875\u9762",
          status: "unknown",
          reason: result.reason,
          lastSeen: Date.now()
        };
        await chrome.storage.session.set({ records: data.records });
        await render(data.records);
      });
      return result;
    }));
    const failed = results.filter((result) => !result.ok).length;
    const connectionError = failed ? `${failed} \u4E2A\u9875\u9762\u672A\u8FDE\u63A5\uFF1A${results.find((result) => !result.ok).reason}` : tabs.length ? "" : "\u672A\u53D1\u73B0\u53EF\u8FDE\u63A5\u7684 ChatGPT \u6807\u7B7E\u9875\u3002\u8BF7\u5728\u5F53\u524D Chrome \u4E2D\u6253\u5F00\u4EFB\u52A1\uFF0C\u5E76\u5141\u8BB8\u6269\u5C55\u8BBF\u95EE chatgpt.com\u3002";
    await chrome.storage.session.set({ connectionError });
    return { ok: failed === 0 && tabs.length > 0, connected: results.length - failed, found: tabs.length };
  })();
  try {
    return await connectionRun;
  } finally {
    connectionRun = null;
  }
}
async function observe(observation, sender) {
  if (!validObservation(observation, sender)) return { ok: false };
  const data = await read();
  const tabId = sender.tab.id;
  const { task, events } = transition(data.records[tabId], observation, Date.now());
  task.tabId = tabId;
  data.records[tabId] = task;
  const { notificationsEnabled = true } = await chrome.storage.local.get("notificationsEnabled");
  const pending = [];
  for (const event of events) {
    const identity = `${task.url}|${event}|${event === "complete" ? task.finishedKey : task.attentionKey}`;
    if (Object.values(data.notices).some((notice) => notice.tabId !== tabId && notice.identity === identity && Date.now() - notice.at < 3e4)) continue;
    if (!notificationsEnabled) continue;
    const id = crypto.randomUUID();
    data.notices[id] = { identity, tabId, url: task.url, at: Date.now() };
    pending.push({ id, event });
  }
  data.notices = Object.fromEntries(Object.entries(data.notices).filter(([, notice]) => Date.now() - notice.at < 864e5));
  await chrome.storage.session.set(data);
  await render(data.records);
  for (const { id, event } of pending) {
    try {
      const permission = await chrome.notifications.getPermissionLevel();
      if (permission !== "granted") throw new Error("Chrome \u901A\u77E5\u6743\u9650\u672A\u542F\u7528");
      await chrome.notifications.create(id, {
        type: "basic",
        iconUrl: "icons/128.png",
        title: event === "attention" ? "\u9700\u8981\u4F60\u5904\u7406 \xB7 ChatGPT" : "\u4EFB\u52A1\u5DF2\u5B8C\u6210 \xB7 ChatGPT",
        message: task.title,
        contextMessage: "\u70B9\u51FB\u8FD4\u56DE\u4EFB\u52A1\u9875\u9762",
        priority: event === "attention" ? 2 : 0,
        requireInteraction: event === "attention"
      });
      await chrome.storage.session.set({ notificationError: "" });
    } catch (error) {
      await chrome.storage.session.set({ notificationError: `\u684C\u9762\u901A\u77E5\u672A\u53D1\u9001\uFF1A${error.message}` });
    }
  }
  return { ok: true };
}
async function openTask(tabId, url) {
  if (!canonicalUrl(url)) return;
  try {
    const tab = await chrome.tabs.get(tabId);
    if (canonicalUrl(tab.url) !== url) throw new Error("Task moved");
    await chrome.tabs.update(tabId, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } catch {
    await chrome.tabs.create({ url });
  }
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message.type === "observation") {
    serial(() => observe(message.observation, sender)).then(respond, () => respond({ ok: false }));
    return true;
  }
  if (sender.id !== chrome.runtime.id || sender.tab) return;
  if (message.type === "getUsage") {
    usageRequest ||= loadUsage(chrome).finally(() => {
      usageRequest = null;
    });
    usageRequest.then(respond, () => respond({ ok: false, reason: "\u5B98\u65B9\u7528\u91CF\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5" }));
    return true;
  }
  if (message.type === "getState") {
    serial(async () => {
      const data = await read();
      const { notificationsEnabled = true } = await chrome.storage.local.get("notificationsEnabled");
      const { connectionError = "" } = await chrome.storage.session.get("connectionError");
      const tasks = Object.values(data.records).map((task) => displayedTask(task, Date.now()));
      return { tasks, status: aggregate(tasks), notificationsEnabled, notificationError: data.notificationError, connectionError, version: chrome.runtime.getManifest?.().version || "development" };
    }).then(respond, () => respond({ error: true }));
    return true;
  }
  if (message.type === "setNotifications" && typeof message.enabled === "boolean") {
    chrome.storage.local.set({ notificationsEnabled: message.enabled }).then(() => respond({ ok: true }));
    return true;
  }
  if (message.type === "openTask") {
    serial(async () => {
      const { records } = await read();
      if (records[message.tabId]) await openTask(message.tabId, records[message.tabId].url);
    }).then(() => respond({ ok: true }));
    return true;
  }
  if (message.type === "rescan") {
    reconnect().then(respond, () => respond({ ok: false }));
    return true;
  }
  if (message.type === "inspectUI") {
    (async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true, url: SITES });
      const tab = tabs.find((tab2) => canonicalUrl(tab2.url));
      if (!tab) return { ok: false, reason: "\u8BF7\u5148\u6253\u5F00\u8981\u68C0\u67E5\u7684 ChatGPT \u9875\u9762\uFF0C\u518D\u70B9\u51FB\u6269\u5C55" };
      const connected = await connectTab(chrome, tab);
      if (!connected.ok) return connected;
      return await chrome.tabs.sendMessage(tab.id, { type: "inspectUI" });
    })().then(respond, () => respond({ ok: false, reason: "\u9875\u9762\u7ED3\u6784\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u540E\u91CD\u8BD5" }));
    return true;
  }
});
chrome.notifications.onClicked.addListener((id) => {
  serial(async () => {
    const { notices } = await read();
    if (notices[id]) await openTask(notices[id].tabId, notices[id].url);
    await chrome.notifications.clear(id);
  });
});
chrome.tabs.onRemoved.addListener((tabId) => serial(async () => {
  const data = await read();
  delete data.records[tabId];
  await chrome.storage.session.set(data);
  await render(data.records);
}));
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.status === "complete") reconnect().catch((error) => console.error(error.message));
  if (!change.url && !change.discarded && change.status !== "loading") return;
  serial(async () => {
    const data = await read();
    if (!data.records[tabId]) return;
    if (change.url && canonicalUrl(change.url) !== data.records[tabId].url) delete data.records[tabId];
    else {
      data.records[tabId].status = "unknown";
      data.records[tabId].reason = "\u9875\u9762\u6B63\u5728\u91CD\u65B0\u52A0\u8F7D\u6216\u5DF2\u4F11\u7720";
      data.records[tabId].candidate = null;
    }
    await chrome.storage.session.set(data);
    await render(data.records);
  });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "freshness") serial(async () => {
    const data = await read();
    const tabs = await chrome.tabs.query({});
    const alive = new Set(tabs.map((tab) => tab.id));
    for (const id of Object.keys(data.records)) if (!alive.has(Number(id))) delete data.records[id];
    await chrome.storage.session.set(data);
    await render(data.records);
  });
});
chrome.alarms.create("freshness", { periodInMinutes: 0.5 });
chrome.runtime.onInstalled.addListener(() => reconnect().catch((error) => console.error(error.message)));
chrome.runtime.onStartup.addListener(() => reconnect().catch((error) => console.error(error.message)));
serial(async () => {
  const data = await read();
  await render(data.records);
}).then(() => reconnect()).catch((error) => console.error(error.message));
