// src/model.js
var LABELS = {
  running: "\u6B63\u5728\u8FDB\u884C",
  attention: "\u9700\u8981\u4F60\u5904\u7406",
  complete: "\u5DF2\u5B8C\u6210",
  idle: "\u7A7A\u95F2",
  stopped: "\u5DF2\u505C\u6B62",
  unknown: "\u672A\u8BC6\u522B",
  error: "\u4EFB\u52A1\u5F02\u5E38"
};

// src/usage.js
function usageView(usage2, now = Date.now()) {
  if (!usage2?.ok) return { available: false, detail: usage2?.reason || "\u6B63\u5728\u8BFB\u53D6\u5B98\u65B9\u989D\u5EA6\u2026" };
  if (now >= usage2.resetAt) return { available: false, detail: "\u5DF2\u5230\u91CD\u7F6E\u65F6\u95F4\uFF0C\u8BF7\u5237\u65B0\u989D\u5EA6" };
  if (now - usage2.fetchedAt >= 3e5) return { available: false, detail: "\u989D\u5EA6\u6570\u636E\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u5237\u65B0" };
  return { available: true, percent: usage2.remainingPercent, resetAt: usage2.resetAt, fetchedAt: usage2.fetchedAt };
}

// src/popup.js
var $ = (id) => document.getElementById(id);
var order = ["attention", "running", "error", "unknown", "stopped", "complete", "idle"];
var lastRender = "";
var usage;
function renderUsage() {
  const view = usageView(usage);
  $("usage-percent").textContent = view.available ? `${Number(view.percent.toFixed(1))}%` : "\u2014";
  $("usage-meter").hidden = !view.available;
  $("usage-meter").value = view.available ? view.percent : 0;
  $("usage-label").textContent = view.available ? "\u5269\u4F59\u989D\u5EA6" : "\u5C1A\u672A\u786E\u8BA4\u989D\u5EA6";
  const time = (value) => new Date(value).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
  $("usage-reset").textContent = view.available ? `\u91CD\u7F6E\u65F6\u95F4\uFF1A${time(view.resetAt)}` : view.detail;
  $("usage-updated").textContent = view.available ? `\u66F4\u65B0\u4E8E ${time(view.fetchedAt)} \xB7 \u5F53\u524D\u767B\u5F55\u8D26\u53F7\u7684\u9ED8\u8BA4\u989D\u5EA6` : "\u4EE5\u5B98\u65B9\u7528\u91CF\u9875\u4E3A\u51C6";
}
async function refreshUsage() {
  const button = $("refresh-usage");
  if (button.disabled) return;
  button.disabled = true;
  usage = null;
  renderUsage();
  try {
    usage = await chrome.runtime.sendMessage({ type: "getUsage" });
  } catch {
    usage = { ok: false, reason: "\u5B98\u65B9\u7528\u91CF\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5" };
  } finally {
    button.disabled = false;
    renderUsage();
  }
}
$("refresh-usage").addEventListener("click", refreshUsage);
$("open-usage").addEventListener("click", () => chrome.tabs.create({ url: "https://chatgpt.com/codex/settings/usage" }));
function element(tag, className, text) {
  const node = document.createElement(tag);
  node.className = className;
  node.textContent = text;
  return node;
}
async function refresh() {
  try {
    const state = await chrome.runtime.sendMessage({ type: "getState" });
    if (!state || state.error) throw new Error("\u6682\u65F6\u65E0\u6CD5\u8FDE\u63A5\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u6269\u5C55");
    const signature = JSON.stringify(state);
    if (signature === lastRender) return;
    lastRender = signature;
    $("signal").className = `signal ${state.status}`;
    $("summary").textContent = state.tasks.length ? LABELS[state.status] : "\u7B49\u5F85\u8FDE\u63A5";
    const count = state.tasks.filter((task) => task.status === "attention").length;
    $("summary-detail").textContent = count ? `${count} \u4E2A\u9875\u9762\u7B49\u5F85\u4F60\u7684\u4E0B\u4E00\u6B65` : !state.tasks.length ? "\u6253\u5F00\u9875\u9762\uFF0C\u8BA9\u8FDB\u5EA6\u4E00\u76EE\u4E86\u7136" : state.status === "unknown" ? "\u5C1A\u672A\u786E\u8BA4\u9875\u9762\u72B6\u6001\uFF0C\u8BF7\u67E5\u770B\u8FDE\u63A5\u8BCA\u65AD" : "\u9700\u8981\u4F60\u65F6\uFF0C\u8FD9\u91CC\u4F1A\u4EAE\u8D77\u9EC4\u706F";
    $("count").textContent = `${state.tasks.length} \u4E2A\u9875\u9762`;
    $("empty").hidden = Boolean(state.tasks.length);
    $("notifications").checked = state.notificationsEnabled;
    const error = [state.connectionError, state.notificationError].filter(Boolean).join("\uFF1B");
    $("error").hidden = !error;
    $("error").textContent = error;
    $("diagnostics").textContent = JSON.stringify({ version: state.version, connection: state.connectionError || "\u5DF2\u8FDE\u63A5", pages: state.tasks.map((task) => ({ state: task.status, signals: task.diagnostics })) }, null, 2);
    const fragment = document.createDocumentFragment();
    for (const task of state.tasks.sort((a, b) => order.indexOf(a.status) - order.indexOf(b.status))) {
      const button = element("button", `task ${task.status}`, "");
      const top = element("div", "task-top", "");
      top.append(element("span", "status-dot", ""), element("span", "task-title", task.title), element("span", "task-status", LABELS[task.status]));
      button.append(top, element("p", "task-reason", task.reason), element("p", "task-time", `\u6700\u8FD1\u68C0\u67E5 ${new Date(task.lastSeen).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}`));
      button.title = "\u6253\u5F00\u6B64\u4EFB\u52A1";
      button.addEventListener("click", async () => {
        await chrome.runtime.sendMessage({ type: "openTask", tabId: task.tabId });
        window.close();
      });
      fragment.append(button);
    }
    $("tasks").replaceChildren(fragment);
  } catch (error) {
    $("error").textContent = error.message;
    $("error").hidden = false;
  }
}
$("notifications").addEventListener("change", async (event) => {
  await chrome.runtime.sendMessage({ type: "setNotifications", enabled: event.target.checked });
  await refresh();
});
async function reconnectPages() {
  const button = $("refresh");
  button.disabled = true;
  try {
    await chrome.runtime.sendMessage({ type: "rescan" });
    await refresh();
  } catch {
    $("error").textContent = "\u91CD\u65B0\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u52A0\u8F7D\u6269\u5C55\u540E\u518D\u8BD5";
    $("error").hidden = false;
  } finally {
    button.disabled = false;
  }
}
$("refresh").addEventListener("click", reconnectPages);
$("inspect-ui").addEventListener("click", async () => {
  const button = $("inspect-ui");
  button.disabled = true;
  try {
    const result = await chrome.runtime.sendMessage({ type: "inspectUI" });
    const area = $("ui-structure");
    area.hidden = false;
    area.value = result?.ok ? JSON.stringify(result.structure, null, 2) : result?.reason || "\u9875\u9762\u7ED3\u6784\u8BFB\u53D6\u5931\u8D25";
    area.focus();
    area.select();
  } finally {
    button.disabled = false;
  }
});
$("open-chat").addEventListener("click", () => chrome.tabs.create({ url: "https://chatgpt.com/" }));
chrome.storage.onChanged.addListener(() => refresh());
refresh();
reconnectPages();
refreshUsage();
setInterval(refresh, 5e3);
setInterval(renderUsage, 1e3);
