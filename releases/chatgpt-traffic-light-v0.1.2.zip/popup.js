// src/model.js
var LABELS = {
  running: "\u6B63\u5728\u8FDB\u884C",
  attention: "\u9700\u8981\u4F60\u5904\u7406",
  complete: "\u5DF2\u5B8C\u6210",
  idle: "\u7A7A\u95F2",
  unknown: "\u72B6\u6001\u672A\u77E5",
  error: "\u4EFB\u52A1\u5F02\u5E38"
};

// src/popup.js
var $ = (id) => document.getElementById(id);
var order = ["attention", "running", "error", "unknown", "complete", "idle"];
var lastRender = "";
function element(tag, className, text) {
  const node = document.createElement(tag);
  node.className = className;
  node.textContent = text;
  return node;
}
async function refresh() {
  try {
    const state = await chrome.runtime.sendMessage({ type: "getState" });
    if (!state || state.error) throw new Error("\u6682\u65F6\u65E0\u6CD5\u8FDE\u63A5\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u6269\u5C55");
    const signature = JSON.stringify(state);
    if (signature === lastRender) return;
    lastRender = signature;
    $("signal").className = `signal ${state.status}`;
    $("summary").textContent = state.tasks.length ? LABELS[state.status] : "\u7B49\u5F85\u8FDE\u63A5";
    const count = state.tasks.filter((task) => task.status === "attention").length;
    $("summary-detail").textContent = count ? `${count} \u4E2A\u9875\u9762\u7B49\u5F85\u4F60\u7684\u4E0B\u4E00\u6B65` : state.tasks.length ? "\u9700\u8981\u4F60\u65F6\uFF0C\u8FD9\u91CC\u4F1A\u4EAE\u8D77\u9EC4\u706F" : "\u6253\u5F00\u9875\u9762\uFF0C\u8BA9\u8FDB\u5EA6\u4E00\u76EE\u4E86\u7136";
    $("count").textContent = `${state.tasks.length} \u4E2A\u9875\u9762`;
    $("empty").hidden = Boolean(state.tasks.length);
    $("notifications").checked = state.notificationsEnabled;
    const error = [state.connectionError, state.notificationError].filter(Boolean).join("\uFF1B");
    $("error").hidden = !error;
    $("error").textContent = error;
    $("diagnostics").textContent = JSON.stringify({ version: state.version, connection: state.connectionError || "\u5DF2\u8FDE\u63A5", pages: state.tasks.map((task) => ({ state: task.status, signals: task.diagnostics })) }, null, 2);
    const fragment = document.createDocumentFragment();
    for (const task of state.tasks.sort((a, b) => order.indexOf(a.status) - order.indexOf(b.status))) {
      const button = element("button", `task ${task.status}`, "");
      const top = element("div", "task-top", "");
      top.append(element("span", "status-dot", ""), element("span", "task-title", task.title), element("span", "task-status", LABELS[task.status]));
      button.append(top, element("p", "task-reason", task.reason), element("p", "task-time", `\u6700\u8FD1\u68C0\u67E5 ${new Date(task.lastSeen).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}`));
      button.title = "\u6253\u5F00\u6B64\u4EFB\u52A1";
      button.addEventListener("click", async () => {
        await chrome.runtime.sendMessage({ type: "openTask", tabId: task.tabId });
        window.close();
      });
      fragment.append(button);
    }
    $("tasks").replaceChildren(fragment);
  } catch (error) {
    $("error").textContent = error.message;
    $("error").hidden = false;
  }
}
$("notifications").addEventListener("change", async (event) => {
  await chrome.runtime.sendMessage({ type: "setNotifications", enabled: event.target.checked });
  await refresh();
});
async function reconnectPages() {
  const button = $("refresh");
  button.disabled = true;
  try {
    await chrome.runtime.sendMessage({ type: "rescan" });
    await refresh();
  } catch {
    $("error").textContent = "\u91CD\u65B0\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u52A0\u8F7D\u6269\u5C55\u540E\u518D\u8BD5";
    $("error").hidden = false;
  } finally {
    button.disabled = false;
  }
}
$("refresh").addEventListener("click", reconnectPages);
$("open-chat").addEventListener("click", () => chrome.tabs.create({ url: "https://chatgpt.com/" }));
chrome.storage.onChanged.addListener(() => refresh());
refresh();
reconnectPages();
setInterval(refresh, 5e3);
